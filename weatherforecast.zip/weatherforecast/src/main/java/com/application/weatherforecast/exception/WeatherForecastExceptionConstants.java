package com.application.weatherforecast.exception;

public class WeatherForecastExceptionConstants {

    public static final String ENTER_CORRECT_CITY = "Please enter a correct city name.";
    public static final String SERVER_NOT_RESPONDING = "Server is not responding, please try after some time. ";
}
